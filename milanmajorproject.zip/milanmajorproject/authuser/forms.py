from django import forms
from .models import CustomUser

class NormalUserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)  # Add this line to include password field

    class Meta:
        model = CustomUser
        fields = ['username', 'full_name', 'email', 'phone', 'password']
